/*
  This is the file coding.h of the CJK macro package ver. 4.1.3
  (20-Jun-1997).
*/


#ifndef __TTF_CODING_H
#define __TTF_CODING_H

#define EUC 0
#define BIG5 1
#define SJIS 2
#define Unicode 3

void get_next_char(unsigned char *cc, int encoding);
void JIS_to_SJIS(unsigned char *cc);

#endif /* __TTF_CODING_H */

/* end of coding.h */
