/*
  This is the file ttf2bmp.h of the CJK macro package ver. 4.1.3
  (20-Jun-1997).
*/


#ifndef __TTF_TTF2BMP_H
#define __TTF_TTF2BMP_H

void convert(TTF *f, BITMAP *bit);

#endif


/* end of ttf2bmp.h */
