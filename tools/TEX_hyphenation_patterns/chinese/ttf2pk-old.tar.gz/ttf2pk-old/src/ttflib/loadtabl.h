/*
  This is the file loadtabl.h of the CJK macro package ver. 4.1.3
  (20-Jun-1997).
*/


#ifndef __TTF_LOADTABL_H
#define __TTF_LOADTABL_H

int load_glyf(TTF *f, FILE *fp, int off, int recursion);

#endif
