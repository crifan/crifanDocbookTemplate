/* mymalloc.h */

char * my_malloc __P((unsigned int len));
