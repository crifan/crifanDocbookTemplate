typedef unsigned char bool;

#define strequ(a,b) (strcmp (a, b) == 0)
#define strnequ(a,b,c) (strncmp (a, b, c) == 0)

#ifndef __P
#ifdef __STDC__
#define __P(a) a
#else
#define __P(a) ()
#endif
#endif

#define UNSUCCESSFUL 1
#define SUCCESSFUL 0

#define TRUE 1
#define FALSE 0

#define NULLCHAR (unsigned char) 0
