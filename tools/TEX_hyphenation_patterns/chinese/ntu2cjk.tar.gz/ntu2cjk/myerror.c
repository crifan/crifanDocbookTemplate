/* myerror.c */

#include <stdio.h>
#ifndef AIX
#   include <stdlib.h>
#endif
#include "defines.h"
#include "myerror.h"

#ifdef __STDC__
void error (char * s)
#else
void error (s)
char * s;
#endif
{
	fprintf (stderr, "\n%s\n", s);
	if (* s == '!') exit (UNSUCCESSFUL);
}

