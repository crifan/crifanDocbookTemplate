/* myopen.h */

FILE * my_open __P((char * file_name, char * extension , char * mode));
