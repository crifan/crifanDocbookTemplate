/* myerror.h */

void error __P((char * s));
