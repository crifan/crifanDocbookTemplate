/* chr2ps.h */

int lenIV = 4;			/* CharString salt length */

typedef struct
{
	char * command;
	int value;
} Command;

Command commands [] =
{
	{ "notdefined_c0",	0 },
	{ "hstem",		1 },
	{ "notdefined_c2",	2 },
	{ "vstem",		3 },
	{ "vmoveto",		4 },
	{ "rlineto",		5 },
	{ "hlineto",		6 },
	{ "vlineto",		7 },
	{ "rrcurveto",		8 },
	{ "closepath",		9 },
	{ "callsubr",		10 },
	{ "return",		11 },
	{ "escape",		12 },
	{ "hsbw",		13 },
	{ "endchar",		14 },
	{ "notdefined_c15",	15 },
	{ "notdefined_c16",	16 },
	{ "notdefined_c17",	17 },
	{ "notdefined_c18",	18 },
	{ "notdefined_c19",	19 },
	{ "notdefined_c20",	20 },
	{ "rmoveto",	21 },
	{ "hmoveto",		22 },
	{ "notdefined_c23",	23 },
	{ "notdefined_c24",	24 },
	{ "notdefined_c25",	25 },
	{ "notdefined_c26",	26 },
	{ "notdefined_c27",	27 },
	{ "notdefined_c28",	28 },
	{ "notdefined_c29",	29 },
	{ "vhcurveto",		30 },
	{ "hvcurveto",		31 }
};

Command escapes[] =
{
	{ "dotsection",		0 },
	{ "vstem3",		1 },
	{ "hstem3",		2 },
	{ "notdefined_e3",	3 },
	{ "notdefined_e4",	4 },
	{ "notdefined_e5",	5 },
	{ "seac",		6 },
	{ "sbw",		7 },
	{ "notdefined_e8",	8 },
	{ "notdefined_e9",	9 },
	{ "notdefined_e10",	10 },
	{ "notdefined_e11",	11 },
	{ "div",		12 },
	{ "notdefined_e13",	13 },
	{ "notdefined_e14",	14 },
	{ "notdefined_e15",	15 },
	{ "callothersubr",	16 },
	{ "pop",		17 },
	{ "notdefined_e18",	18 },
	{ "notdefined_e19",	19 },
	{ "notdefined_e20",	20 },
	{ "notdefined_e21",	21 },
	{ "notdefined_e22",	22 },
	{ "notdefined_e23",	23 },
	{ "notdefined_e24",	24 },
	{ "notdefined_e25",	25 },
	{ "notdefined_e26",	26 },
	{ "notdefined_e27",	27 },
	{ "notdefined_e28",	28 },
	{ "notdefined_e29",	29 },
	{ "notdefined_e30",	30 },
	{ "notdefined_e31",	31 },
	{ "notdefined_e32",	32 },
	{ "setcurrentpoint",	33 }
};

#define MAX_ESCAPE		33

#define CR			4330
#define CC1			52845
#define CC2			22719

#define CHARSIZE 4000
#define LINESIZE 4000
#define TEMPSIZE 20

#define out_break 120


FILE * chr_file, * ps_file;

unsigned char HaveSavedChar = FALSE;
char SavedChar;

unsigned short int cr, cc1, cc2;
unsigned char CharString [CHARSIZE], inchar, testchar, prevchar;
unsigned char byte, temp_buff [TEMPSIZE];
unsigned char in_buff [LINESIZE], * char_pos, * rd_pos, * count_pos;
int in_size, rd_index, tp, btp, CP, i, copycount, count, restcount;

unsigned char ReadChar __P((void));
void ReadLine __P((void));
void DecryptCharString __P((unsigned char * CS, int count));
unsigned char DeCrypt __P((unsigned char cipher));
