/* mymalloc.c */

#include <stdio.h>
#ifndef AIX
#   include <stdlib.h>
#endif
#include "defines.h"
#include "myerror.h"
#include "mymalloc.h"

#ifdef __STDC__
char * my_malloc (unsigned int len)
#else
char * my_malloc (unsigned len)
int len;
#endif
{
	char * p;

	p = (char *) malloc (len);
	if (p == NULL) error ("! out of memory");
	return (p);
}
 
