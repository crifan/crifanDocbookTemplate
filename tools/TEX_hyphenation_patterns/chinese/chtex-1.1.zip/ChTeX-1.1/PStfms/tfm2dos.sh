mv AvantGarde-Book.tfm av-bk.tfm
mv AvantGarde-BookOblique.tfm av-bkob.tfm
mv AvantGarde-Demi.tfm av-de.tfm
mv AvantGarde-DemiOblique.tfm av-deob.tfm
mv AvantGarde-SmallCaps.tfm av-sc.tfm
mv Bookman-Demi.tfm bo-de.tfm
mv Bookman-DemiItalic.tfm bo-deit.tfm
mv Bookman-Light.tfm bo-lt.tfm
mv Bookman-LightItalic.tfm bo-ltit.tfm
mv Bookman-SmallCaps.tfm bo-sc.tfm
mv Courier-Bold.tfm co-bd.tfm
mv Courier-BoldOblique.tfm co-bdob.tfm
mv Courier-Oblique.tfm co-ob.tfm
mv Helvetica-Bold.tfm he-bd.tfm
mv Helvetica-BoldOblique.tfm he-bdob.tfm
mv Helvetica-Narrow-Bold.tfm he-nrbd.tfm
mv Helvetica-Narrow-BoldOblique.tfm he-nrbdob.tfm
mv Helvetica-Narrow-Oblique.tfm he-nrob.tfm
mv Helvetica-Narrow.tfm he-nr.tfm
mv Helvetica-Oblique.tfm he-ob.tfm
mv LubalinGraph-Book.tfm lu-bk.tfm
mv LubalinGraph-BookOblique.tfm lu-bkob.tfm
mv LubalinGraph-Demi.tfm lu-de.tfm
mv LubalinGraph-DemiOblique.tfm lu-deob.tfm
mv NewBaskerville-Bold.tfm ne-bd.tfm
mv NewBaskerville-BoldItalic.tfm ne-bdit.tfm
mv NewBaskerville-Italic.tfm ne-it.tfm
mv NewBaskerville-Roman.tfm ne-roman.tfm
mv NewCenturySchlbk-Bold.tfm ne-bd.tfm
mv NewCenturySchlbk-BoldItalic.tfm ne-bdit.tfm
mv NewCenturySchlbk-Italic.tfm ne-it.tfm
mv NewCenturySchlbk-Roman.tfm ne-roman.tfm
mv NewCenturySchlbk-SmallCaps.tfm ne-sc.tfm
mv Palatino-Bold.tfm pa-bd.tfm
mv Palatino-BoldItalic.tfm pa-bdit.tfm
mv Palatino-Italic.tfm pa-it.tfm
mv Palatino-Oblique.tfm pa-ob.tfm
mv Palatino-Roman.tfm pa-roman.tfm
mv Palatino-SmallCaps.tfm pa-sc.tfm
mv Souvenir-Demi.tfm so-de.tfm
mv Souvenir-DemiItalic.tfm so-deit.tfm
mv Souvenir-Light.tfm so-lt.tfm
mv Souvenir-LightItalic.tfm so-ltit.tfm
mv Times-Bold.tfm ti-bd.tfm
mv Times-BoldItalic.tfm ti-bdit.tfm
mv Times-Italic.tfm ti-it.tfm
mv Times-Oblique.tfm ti-ob.tfm
mv Times-Roman.tfm ti-roman.tfm
mv Times-SmallCaps.tfm ti-sc.tfm
mv ZapfChancery-MediumItalic.tfm za-mdit.tfm
mv ZapfDingbats.tfm zap.tfm











