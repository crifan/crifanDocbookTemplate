/* make GuoBiao table mkgb.c */
#include <stdio.h>

FILE *outpt;

main()
{
int i, j;
fputs("\nGenerating > gbtable0.txt", stderr);
outpt = fopen("gbtable0.txt", "w");
fprintf(outpt, "\
.lh ���ű�\n\
");
pre_define();
for (i=161; i<171; i++)
{ fprintf(outpt, ".nc 1\n");
  for (j=161; j< 255; j++)
  {
  fprintf(outpt, ".fs8\n%02x%02x\n.fs12\n", i, j);	
  fprintf(outpt, "%c%c\n.nc\n", i, j);
  }
}
fclose(outpt);

outpt = fopen("gbtable1.txt", "w");
fputs("\nGenerating > gbtable1.txt", stderr);
fprintf(outpt, ".pn3\n\
.lh һ���ֿ�\n\
");
pre_define();
for (i=176; i<196; i++)
{ fprintf(outpt, ".nc 1\n");
  for (j=161; j< 255; j++)
  {
  fprintf(outpt, ".fs8\n%02x%02x\n.fs12\n", i, j);	
  fprintf(outpt, "%c%c\n.nc\n", i, j);
  }
}
 fclose(outpt);

outpt = fopen("gbtable2.txt", "w");
fputs("\nGenerating > gbtable2.txt", stderr);
pre_define();
fprintf(outpt, ".pn7\n\
.lh һ���ֿ�\n");
for (i=196; i<216; i++)
{ fprintf(outpt, ".nc 1\n");
  for (j=161; j< 255; j++)
  {
  fprintf(outpt, ".fs8\n%02x%02x\n.fs12\n", i, j);	
  fprintf(outpt, "%c%c\n.nc\n", i, j);
  }
}
 fclose(outpt);


outpt = fopen("gbtable3.txt", "w");
fputs("\nGenerating > gbtable3.txt", stderr);
pre_define();
fprintf(outpt, ".pn11\n\
.lh �����ֿ�\n");
for (i=216; i<236; i++)
{ fprintf(outpt, ".nc 1\n");
  for (j=161; j< 255; j++)
  {
  fprintf(outpt, ".fs8\n%02x%02x\n.fs12\n", i, j);	
  fprintf(outpt, "%c%c\n.nc\n", i, j);
  }
}
 fclose(outpt);


outpt = fopen("gbtable4.txt", "w");
fputs("\nGenerating > gbtable4.txt", stderr);
pre_define();
fprintf(outpt, ".pn15\n\
.lh �����ֿ�\n");
for (i=236; i<248; i++)
{ fprintf(outpt, ".nc 1\n");
  for (j=161; j< 255; j++)
  {
  fprintf(outpt, ".fs8\n%02x%02x\n.fs12\n", i, j);	
  fprintf(outpt, "%c%c\n.nc\n", i, j);
  }
}
 fclose(outpt);

fputs("\nGenerating > fonts.txt\n", stderr);
fonts();
fclose(outpt);
}

pre_define()
{
 fprintf(outpt, ".ls1.2\n\
.ns10\n\
.ffTimes\n\
.rh �����(GuoBiao table)\n\
.cn20\n\
.pf\n\
.ce\n");
}

fonts()
{
int i, j, k;

outpt = fopen("fonts.txt", "w");
non_symbol();
symbol();
Times();
Helve();
Courier();
}

non_symbol()
{
int i, j, k;
fprintf(outpt,".if fonts.hdr\n\
.pa\n\
.ffTimes\n\
.lm 2in\n\
.rm 2in\n\
.rh Standard Adobe Encoding\n");
fprintf(outpt,".fs+2\n\
.ce\n\
.bf\n\
Standard Adobe Encoding for Non-Symbol Fonts\n\
.rf\n\
.fs-2\n\n\
.cn9\n");
fprintf(outpt, "octal\n\
.nc\n\
0\n\
.nc\n\
1\n\
.nc\n\
2\n\
.nc\n\
3\n\
.nc\n\
4\n\
.nc\n\
5\n\
.nc\n\
6\n\
.nc\n\
7\n\
.nc 1\n");
fprintf(outpt, "\\00^ix^i\n\.nc 1\n\
\\01^ix^i\n\.nc 1\n\
\\02^ix^i\n\.nc 1\n\
\\03^ix^i\n\.nc 1\n");

k=4;

for(j=32; j<127; j+=8)
 {
	fprintf(outpt, "\\%02d^ix^i\n\.nc\n", k);
	k++;
	if (k==8) k=10;
	for(i=j; i<j+8; i++)
	{
	if(i=='.')
	fprintf(outpt, " %c\n.nc\n", i);
	else if(i=='^')
         fprintf(outpt, "^%c\n.nc\n", i);
	else if(i=='%')
	fprintf(outpt, "^%c\n.nc\n", i);
	else if(i==127) break;
	else
	fprintf(outpt, "%c\n.nc\n", i);
	}

  }

fprintf(outpt, ".nc 1\n\\20^ix^i\n\.nc 1\n\
\\21^ix^i\n\.nc 1\n\
\\22^ix^i\n\.nc 1\n\
\\23^ix^i\n\.nc 1\n");
fprintf(outpt, "\\24^ix^i\n\.nc 3\n\
^#241\n.nc\n^#242\n.nc\n^#243\n.nc\n^#244\n.nc\n^#245\n.nc\n^#246\n.nc\n^#247\n.nc 1\n");

fprintf(outpt, "\\25^ix^i\n.nc\n^#250\n.nc\n\
^#251\n.nc\n^#252\n.nc\n^#253\n.nc\n^#254\n.nc\n^#255\n.nc\n^#256\n.nc\n^#257\n.nc 1\n");

fprintf(outpt, "\\26^ix^i\n.nc 3\n\
^#261\n.nc\n^#262\n.nc\n^#263\n.nc\n^#264\n.nc\n \n.nc\n^#266\n.nc\n^#267\n.nc 1\n");


fprintf(outpt, "\\27^ix^i\n.nc\n^#270\n.nc\n\
^#271\n.nc\n^#272\n.nc\n^#273\n.nc\n^#274\n.nc\n^#275\n.nc\n \n.nc\n^#277\n.nc 1\n");

fprintf(outpt, "\\30^ix^i\n.nc 3\n\
^#301\n.nc\n^#302\n.nc\n^#303\n.nc\n^#304\n.nc\n^#305\n.nc\n^#306\n.nc\n^#307\n.nc\n");


fprintf(outpt, "\\31^ix^i\n.nc\n^#310\n.nc\n\
 \n.nc\n^#312\n.nc\n^#313\n.nc\n \n.nc\n^#315\n.nc\n^#316\n.nc\n^#317\n.nc 1\n");
 
fprintf(outpt, "\\32^ix^i\n.nc\n^#320\n.nc 1\n");

fprintf(outpt, "\\33^ix^i\n.nc 1\n");

fprintf(outpt, "\\34^ix^i\n.nc 3\n\
^#341\n.nc\n \n.nc\n^#343\n.nc 1\n");

fprintf(outpt, "\\35^ix^i\n.nc\n^#350\n.nc\n\
^#351\n.nc\n^#352\n.nc\n^#353\n.nc 1\n");

fprintf(outpt, "\\36^ix^i\n.nc 3\n\
^#361\n.nc 7\n^#365\n.nc 1\n");

fprintf(outpt, "\\37^ix^i\n.nc\n^#370\n.nc\n\
^#371\n.nc\n^#372\n.nc\n^#373\n");
fprintf(outpt, ".lm 1in\n\
.rm 1in\n.pa\n");
}


symbol()
{
int i, j, k;

fprintf(outpt,"\
.lm 2in\n\
.rm 2in\n\
.rh Standard Adobe Encoding\n");
fprintf(outpt,".fs+2\n\
.cn 1\n\
.ce\n\
.bf\n\
Standard Adobe Encoding for Symbol Font\n\
.rf\n\
.fs-2\n\n\
.cn9\n");
fprintf(outpt, "octal\n.nc\n\
.sb\n\
0\n\
.nc\n\
1\n\
.nc\n\
2\n\
.nc\n\
3\n\
.nc\n\
4\n\
.nc\n\
5\n\
.nc\n\
6\n\
.nc\n\
7\n\
.nc\n");

fprintf(outpt, "^i\\^i00^ix^i\n\.nc 1\n\
^i\\^i01^ix^i\n\.nc 1\n\
^i\\^i02^ix^i\n\.nc 1\n\
^i\\^i03^ix^i\n\.nc 1\n");

k=4;

for(j=32; j<127; j+=8)
 {
	fprintf(outpt, "^i\\^i%02d^ix^i\n\.nc\n", k);
	k++;
	if (k==8) k=10;
	for(i=j; i<j+8; i++)
	{
	if(i=='.')
	fprintf(outpt, " %c\n.nc\n", i);
	else if(i=='^')
	fprintf(outpt, "^%c\n.nc\n", i);
	else if(i=='%')
	fprintf(outpt, "^%c\n.nc\n", i);
	else if(i==127) break;
	else
	fprintf(outpt, "%c\n.nc\n", i);
	}

  }

fprintf(outpt, ".nc 1\n^i\\^i20^ix^i\n\.nc 1\n\
^i\\^i21^ix^i\n\.nc 1\n\
^i\\^i22^ix^i\n\.nc 1\n\
^i\\^i23^ix^i\n\.nc 1\n");
fprintf(outpt, "^i\\^i24^ix^i\n\.nc 3\n\
^#241\n.nc\n^#242\n.nc\n^#243\n.nc\n^#244\n.nc\n^#245\n.nc\n^#246\n.nc\n^#247\n.nc\n");

k=25;
for(j=168; j<255; j+=8)
 {
	fprintf(outpt, ".nc 1\n^i\\^i%02d^ix^i\n\.nc\n", k);
	k++;
	if (k==28) k=30;

	for(i=j; i<j+8; i++)
	{
		if (i>254) break;
	fprintf(outpt, "^%d\n.nc\n", i);
	}
  }

fprintf(outpt, ".lm 1in\n\
.rm 1in");

}


fontS()
{
int i, j;

for(j=32; j<127; j++)
	fprintf(outpt, "%c", j);
fprintf(outpt, "\n.nc 1\n\n\n.nc 1\n");
}

Times()
{
fprintf(outpt, "\
\n.pa\n\
.fs12\n\
.nf\n\
.in0\n\
.rh Times Family\n\
.ffTimes\n\
.cn2\n\
.cr 1 5\n\
");

fprintf(outpt, "\
.rt\n\
Times-\n\
Roman\n\
.nc\n\
");
fontS();

fprintf(outpt, "\
.bf\n\
Times-\n\
Bold\n\
.nc\n\
");
fontS();

fprintf(outpt, "\
.it\n\
Times-\n\
Italic\n\
.nc\n\
");
fontS();

fprintf(outpt, "\
.ph\n\
Times-\n\
BoldItalic\n\
.nc\n\
");
fontS();

}


Helve()
{
fprintf(outpt, "\
\n.pa\n\
.fs12\n\
.rh Helvetica Family\n\
.ffHelve\n\
.cn2\n\
.cr 1 5\n\
.nf\n\
");

fprintf(outpt, "\
.rt\n\
Helvetica\n\
.nc\n\
");
fontS();

fprintf(outpt, "\
.bf\n\
Helvetica-\n\
Bold\n\
.nc\n\
");
fontS();

fprintf(outpt, "\
.it\n\
Helvetica-\n\
Oblique\n\
.nc\n\
");
fontS();

fprintf(outpt, "\
.ph\n\
Helvetica-\n\
BoldOblique\n\
.nc\n\
");
fontS();

}



Courier()
{
fprintf(outpt, "\
\n.pa\n\
.fs12\n\
.rh Courier Family\n\
.ffHelve\n\
.cn2\n\
.cr 1 5\n\
.nf\n\
");

fprintf(outpt, "\
.rt\n\
Courier\n\
.nc\n\
");
fontS();

fprintf(outpt, "\
.bf\n\
Courier-\n\
Bold\n\
.nc\n\
");
fontS();

fprintf(outpt, "\
.it\n\
Courier-\n\
Oblique\n\
.nc\n\
");
fontS();

fprintf(outpt, "\
.ph\n\
Courier-\n\
BoldOblique\n\
.nc\n\
");
fontS();

}

