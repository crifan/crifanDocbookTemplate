/*
 * cc2tex - program to put Chinese character into latex
 *
 * Zhi Biao Wu
 * Department of Information System & Computer Science 
 * Natural University of Singapore
 * 1992
 *
 * Copyright (c) 1992, Zhi Biao Wu,ISCS,NUS.
 * All rights reserved.
 *
 * Use and copying of this software and preparation of derivative works
 * based upon this software are permitted.  However, any distribution of
 * this software or derivative works must include the above copyright
 * notice.
 *
 * This software is made available AS IS, and neither the Department of 
 * Information system & Computer Science or the writer make any
 * warranty about the software, its performance or its conformity to
 * any specification.
 */

#ifndef _RIGHTS_
#define _RIGHTS_

static char copyright[] = "Copyright (c) 1992, Zhi Biao Wu, iscs,nus.  All rights reserved.";

#endif /* _RIGHTS_ */
